 
"use client";
import { createContext, useContext } from "react";
import type { User } from "./lib";

export type Ctx = { user: User; notify: (text: string, tone?: "ok" | "risk") => void; go: (hash: string) => void };
export const AdminCtx = createContext<Ctx | null>(null);
export const useAdmin = () => useContext(AdminCtx)!;
