/* eslint-disable @typescript-eslint/no-explicit-any -- admin views render loosely-typed API JSON */
"use client";

import { useState } from "react";
import { api, can, fmtDate } from "./lib";
import { useAdmin } from "./ctx";
import { Badge, Btn, Card, Empty, ErrorBox, Field, inputCls, Loading, Page, Table, Td, useLoad } from "./ui";

const err = (e: unknown) => (e as Error).message;

export function SettingsView() {
  const { user } = useAdmin();
  const [tab, setTab] = useState("general");
  const tabs = [["general", "General"], ["users", "Users"], ["emails", "Email queue"], ["privacy", "Privacy & retention"], ...(can(user, "audit") ? [["audit", "Audit log"]] : []), ["account", "My account"]];
  return (
    <Page title="Settings">
      <div role="tablist" className="mb-6 flex flex-wrap gap-1 border-b border-line">
        {tabs.map(([k, l]) => <button key={k} role="tab" aria-selected={tab === k} onClick={() => setTab(k)} className={`-mb-px border-b-2 px-4 py-2 text-sm font-semibold ${tab === k ? "border-brand text-heading" : "border-transparent text-muted hover:text-heading"}`}>{l}</button>)}
      </div>
      {tab === "general" && <General />}{tab === "users" && <UsersTab />}{tab === "emails" && <Emails />}{tab === "privacy" && <Privacy />}{tab === "audit" && <Audit />}{tab === "account" && <Account />}
    </Page>
  );
}

function General() {
  const { notify } = useAdmin();
  const { data, error, loading, setData, reload } = useLoad(() => api("GET", "/settings"));
  if (loading) return <Loading />;
  if (error || !data) return <ErrorBox>{error}</ErrorBox>;
  const s = data.settings; const set = (k: string, v: unknown) => setData({ settings: { ...s, [k]: v } });
  const num = (k: string, label: string, hint?: string) => <Field label={label} hint={hint}><input type="number" className={inputCls} value={s[k]} onChange={(e) => set(k, Number(e.target.value))} /></Field>;
  const chk = (k: string, label: string) => <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="check" checked={!!s[k]} onChange={(e) => set(k, e.target.checked)} /> {label}</label>;
  const ls = s.lead_scoring;
  return (
    <div className="space-y-6">
      <Card title="Notifications">
        <div className="grid gap-3">
          <Field label="Notify these addresses about new leads" hint="Comma-separated. Notifications never contain assessment findings or contact details."><input className={inputCls} value={(s.notify_emails ?? []).join(", ")} onChange={(e) => set("notify_emails", e.target.value.split(/[,\s]+/).filter(Boolean))} /></Field>
          {chk("notify_on_new_lead", "Every new lead")}{chk("notify_on_consultation", "Consultation requests")}{chk("notify_high_priority_only", "Only high-priority leads")}{chk("participant_emails", "Send confirmation and report emails to participants")}
        </div>
      </Card>
      <Card title="Links and abuse protection">
        <div className="grid gap-3 sm:grid-cols-3">{num("report_link_days", "PDF link valid (days)")}{num("result_link_days", "Results link valid (days)")}{num("min_completion_seconds", "Minimum completion time (s)", "Faster submissions are treated as bots.")}</div>
        <div className="mt-3">{chk("track_steps", "Record anonymous step progress (for drop-off analytics)")}</div>
      </Card>
      <Card title="Lead qualification points" >
        <p className="mb-3 text-xs text-muted">Commercial priority only; never derived from the maturity score.</p>
        <div className="grid gap-3 sm:grid-cols-3">
          {["consultation", "report_only", "per_interest", "max_interest", "high", "medium"].map((k) => <Field key={k} label={k.replace("_", " ")}><input type="number" className={inputCls} value={ls[k]} onChange={(e) => set("lead_scoring", { ...ls, [k]: Number(e.target.value) })} /></Field>)}
        </div>
      </Card>
      <Btn kind="primary" onClick={async () => { try { await api("PUT", "/settings", { settings: s }); notify("Settings saved."); reload(); } catch (e) { notify(err(e), "risk"); } }}>Save settings</Btn>
    </div>
  );
}

function UsersTab() {
  const { user, notify } = useAdmin();
  const { data, error, loading, reload } = useLoad(() => api("GET", "/users"), []);
  const [n, setN] = useState({ email: "", name: "", role: "sales", password: "" });
  if (!can(user, "users")) return <Empty>Only owners and admins can manage users.</Empty>;
  if (loading) return <Loading />;
  if (error || !data) return <ErrorBox>{error}</ErrorBox>;
  const upd = async (id: number, b: any) => { try { await api("PUT", `/users/${id}`, b); notify("User updated."); reload(); } catch (e) { notify(err(e), "risk"); } };
  return (
    <div className="space-y-6">
      <Card title="Roles"><p className="text-sm text-body"><b>Owner/Admin</b>: everything · <b>Editor</b>: assessment content, no personal data · <b>Sales</b>: leads, reports, exports · <b>Viewer</b>: analytics and content (read-only).</p></Card>
      <Table head={["User", "Role", "Status", "Two-factor", "Last login", ""]}>
        {data.users.map((u: any) => (
          <tr key={u.id}><Td><b className="text-heading">{u.name}</b><span className="block text-xs text-muted">{u.email}</span></Td>
            <Td><select className={inputCls} value={u.role} onChange={(e) => upd(u.id, { role: e.target.value })} aria-label="Role">{data.roles.map((r: string) => <option key={r}>{r}</option>)}</select></Td>
            <Td>{u.active ? <Badge tone="ok">active</Badge> : <Badge>disabled</Badge>}</Td><Td>{u.mfa_enabled_at ? <Badge tone="ok">on</Badge> : <Badge tone="warn">set up at next sign-in</Badge>}</Td><Td>{fmtDate(u.last_login_at)}</Td>
            <Td className="space-x-1"><Btn small onClick={() => upd(u.id, { active: !u.active })}>{u.active ? "Disable" : "Enable"}</Btn><Btn small onClick={() => { const p = prompt("New password (min 12 characters)"); if (p) upd(u.id, { password: p }); }}>Reset password</Btn>{u.mfa_enabled_at && <Btn small onClick={() => { if (confirm(`Reset two-factor sign-in for ${u.name}? They will set it up again with a new QR code at their next sign-in, and are signed out everywhere.`)) upd(u.id, { reset_2fa: true }); }}>Reset 2FA</Btn>}</Td></tr>
        ))}
      </Table>
      <Card title="Add user">
        <form className="grid gap-3 sm:grid-cols-5 sm:items-end" onSubmit={async (e) => { e.preventDefault(); try { await api("POST", "/users", n); setN({ email: "", name: "", role: "sales", password: "" }); notify("User created."); reload(); } catch (x) { notify(err(x), "risk"); } }}>
          <Field label="Name"><input className={inputCls} required value={n.name} onChange={(e) => setN({ ...n, name: e.target.value })} /></Field>
          <Field label="Email"><input type="email" className={inputCls} required value={n.email} onChange={(e) => setN({ ...n, email: e.target.value })} /></Field>
          <Field label="Role"><select className={inputCls} value={n.role} onChange={(e) => setN({ ...n, role: e.target.value })}>{data.roles.map((r: string) => <option key={r}>{r}</option>)}</select></Field>
          <Field label="Temporary password"><input type="password" minLength={12} className={inputCls} required value={n.password} onChange={(e) => setN({ ...n, password: e.target.value })} /></Field>
          <Btn type="submit" kind="primary">Add</Btn>
        </form>
      </Card>
    </div>
  );
}

function Emails() {
  const { notify } = useAdmin();
  const { data, error, loading, reload } = useLoad(() => api("GET", "/emails"));
  const [to, setTo] = useState("");
  return (
    <div className="space-y-6">
      <Card title="Send a test email">
        <form className="flex flex-wrap gap-2" onSubmit={async (e) => { e.preventDefault(); try { const r = await api("POST", "/emails/test", { to }); notify(r.sent ? "Test email sent." : "Delivery failed; it is queued for retry.", r.sent ? "ok" : "risk"); reload(); } catch (x) { notify(err(x), "risk"); } }}>
          <input type="email" required aria-label="Recipient" className={`${inputCls} max-w-xs`} value={to} onChange={(e) => setTo(e.target.value)} placeholder="you@example.com" /><Btn type="submit">Send test</Btn>
          <Btn onClick={async () => { const r = await api("POST", "/emails/process", {}); notify(`Processed queue: ${r.sent} sent, ${r.failed} failed.`); reload(); }}>Process queue now</Btn>
        </form>
      </Card>
      {loading ? <Loading /> : error ? <ErrorBox>{error}</ErrorBox> : !data.emails.length ? <Empty>No emails yet.</Empty> : (
        <Table head={["Type", "Status", "Attempts", "Created", "Sent / next try", "Error", ""]}>
          {data.emails.map((m: any) => (
            <tr key={m.id}><Td>{m.kind}{m.lead_id && <a className="block text-xs text-cobalt" href={`#/leads/${m.lead_id}`}>lead</a>}</Td><Td><Badge tone={m.status === "sent" ? "ok" : m.status === "failed" ? "risk" : "warn"}>{m.status}</Badge></Td><Td>{m.attempts}</Td><Td>{fmtDate(m.created_at)}</Td>
              <Td>{fmtDate(m.sent_at ?? m.next_attempt_at)}</Td><Td className="max-w-xs text-xs">{m.last_error}</Td>
              <Td>{m.status === "failed" && <Btn small onClick={async () => { await api("POST", `/emails/${m.id}/retry`, {}); reload(); }}>Retry</Btn>}</Td></tr>
          ))}
        </Table>
      )}
    </div>
  );
}

function Privacy() {
  const { user, notify } = useAdmin();
  const [email, setEmail] = useState(""); const [found, setFound] = useState<any[] | null>(null);
  return (
    <div className="space-y-6">
      {can(user, "export") && (
        <Card title="Data subject request">
          <p className="mb-3 text-sm text-body">Find every lead for an email address to export or erase it (GDPR access and erasure requests).</p>
          <form className="flex flex-wrap gap-2" onSubmit={async (e) => { e.preventDefault(); try { setFound((await api("POST", "/privacy/lookup", { email })).leads); } catch (x) { notify(err(x), "risk"); } }}>
            <input type="email" required aria-label="Email address" className={`${inputCls} max-w-xs`} value={email} onChange={(e) => setEmail(e.target.value)} /><Btn type="submit">Find</Btn>
          </form>
          {found && (found.length ? <ul className="mt-3 space-y-1 text-sm">{found.map((l) => <li key={l.id}><a className="text-cobalt" href={`#/leads/${l.id}`}>{l.public_ref}</a> · {l.source} · {fmtDate(l.created_at)}</li>)}</ul> : <p className="mt-3 text-sm text-muted">No records found.</p>)}
        </Card>
      )}
      <Card title="Data retention">
        <p className="text-sm text-body">Retention periods are set under General settings in the database (defaults: anonymous assessments 365 days, leads 730 days unless converted, sessions 180 days, audit log 730 days). Retention runs daily via cron.</p>
        <div className="mt-3"><Btn onClick={async () => { if (!confirm("Run retention now? Expired records are permanently deleted.")) return; const r = await api("POST", "/retention/run", {}); notify(`Retention complete: ${Object.entries(r).map(([k, v]) => `${k} ${v}`).join(", ")}`); }}>Run retention now</Btn></div>
      </Card>
    </div>
  );
}

function Audit() {
  const [page, setPage] = useState(1);
  const { data, error, loading } = useLoad(() => api("GET", `/audit?page=${page}`), [page]);
  if (loading) return <Loading />;
  if (error || !data) return <ErrorBox>{error}</ErrorBox>;
  return (
    <>
      <Table head={["When", "User", "Action", "Target", "Details"]}>
        {data.entries.map((e: any) => <tr key={e.id}><Td className="whitespace-nowrap">{fmtDate(e.created_at)}</Td><Td>{e.user_name ?? "system"}</Td><Td>{e.action}</Td><Td>{e.entity ? `${e.entity} #${e.entity_id}` : "–"}</Td><Td className="max-w-md break-all font-mono text-xs">{e.meta ? JSON.stringify(e.meta) : ""}</Td></tr>)}
      </Table>
      <div className="mt-3 flex gap-2"><Btn small disabled={page <= 1} onClick={() => setPage(page - 1)}>Newer</Btn><Btn small disabled={data.entries.length < 50} onClick={() => setPage(page + 1)}>Older</Btn></div>
    </>
  );
}

function Account() {
  const { notify } = useAdmin();
  const [cur, setCur] = useState(""); const [pw, setPw] = useState("");
  const { data, reload } = useLoad(() => api("GET", "/mfa"));
  const [code, setCode] = useState(""); const [codes, setCodes] = useState<string[] | null>(null);
  return (
    <div className="space-y-6">
      <Card title="Two-factor sign-in">
        {!data ? <Loading /> : (
          <div className="space-y-4 text-sm">
            <p className="text-body"><Badge tone="ok">on</Badge> since {fmtDate(data.enabled_at)}. {data.recovery_remaining} of 10 backup codes left.</p>
            <form className="flex flex-wrap items-end gap-2" onSubmit={async (e) => { e.preventDefault(); try { const r = await api("POST", "/mfa/recovery-codes", { code }); setCodes(r.recovery_codes); setCode(""); reload(); } catch (x) { notify(err(x), "risk"); } }}>
              <Field label="New backup codes" hint="Enter a code from your authenticator app. Your old backup codes stop working."><input className={`${inputCls} w-40 font-mono`} inputMode="numeric" autoComplete="one-time-code" maxLength={6} value={code} onChange={(e) => setCode(e.target.value.replace(/[^0-9]/g, ""))} /></Field>
              <Btn type="submit" disabled={code.length !== 6}>Create new codes</Btn>
            </form>
            {codes && <div className="rounded-md bg-paper p-4"><p className="font-semibold text-heading">Your new backup codes (shown once):</p><ul className="mt-2 grid grid-cols-2 gap-1 font-mono">{codes.map((c) => <li key={c}>{c}</li>)}</ul><Btn small onClick={() => navigator.clipboard?.writeText(codes.join("\n"))}>Copy</Btn></div>}
            <div>
              <p className="font-semibold text-heading">Trusted browsers</p>
              {data.devices.length ? (
                <ul className="mt-2 divide-y divide-line">{data.devices.map((d: any) => (
                  <li key={d.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
                    <span>{d.label}{d.current && <> <Badge tone="brand">this browser</Badge></>} <span className="text-xs text-muted">added {fmtDate(d.created_at)} · expires {fmtDate(d.expires_at)}</span></span>
                    <Btn small onClick={async () => { await api("DELETE", `/mfa/devices?id=${d.id}`); reload(); }}>Forget</Btn>
                  </li>))}
                </ul>
              ) : <p className="mt-1 text-muted">No trusted browsers. Every sign-in asks for a code.</p>}
              {data.devices.length > 0 && <div className="mt-2"><Btn small kind="danger" onClick={async () => { await api("DELETE", "/mfa/devices"); notify("All trusted browsers forgotten."); reload(); }}>Forget all</Btn></div>}
            </div>
          </div>
        )}
      </Card>
      <Card title="Change password">
        <form className="grid max-w-sm gap-3" onSubmit={async (e) => { e.preventDefault(); try { await api("POST", "/password", { current: cur, password: pw }); setCur(""); setPw(""); notify("Password changed."); } catch (x) { notify(err(x), "risk"); } }}>
          <Field label="Current password"><input type="password" autoComplete="current-password" className={inputCls} required value={cur} onChange={(e) => setCur(e.target.value)} /></Field>
          <Field label="New password" hint="At least 12 characters."><input type="password" autoComplete="new-password" minLength={12} className={inputCls} required value={pw} onChange={(e) => setPw(e.target.value)} /></Field>
          <Btn type="submit" kind="primary">Change password</Btn>
        </form>
      </Card>
    </div>
  );
}
