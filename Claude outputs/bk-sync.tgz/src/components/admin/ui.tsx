/* eslint-disable @typescript-eslint/no-explicit-any -- admin views render loosely-typed API JSON */
"use client";

import { useCallback, useEffect, useRef, useState, type ReactNode } from "react";
import { Loader2 } from "lucide-react";
import { AdminError } from "./lib";

export function useLoad<T>(fn: () => Promise<T>, deps: unknown[] = []) {
  const [data, setData] = useState<T | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [tick, setTick] = useState(0);
  const fnRef = useRef(fn);
  useEffect(() => { fnRef.current = fn; });
  const key = JSON.stringify(deps);
  useEffect(() => {
    let live = true;
    fnRef.current().then((d) => { if (live) { setData(d); setError(null); } }).catch((e: AdminError) => { if (live) setError(e.message); }).finally(() => { if (live) setLoading(false); });
    return () => { live = false; };
  }, [key, tick]);
  const reload = useCallback(() => { setLoading(true); setTick((t) => t + 1); }, []);
  return { data, error, loading, reload, setData };
}

export function Page({ title, actions, children, lead }: { title: string; actions?: ReactNode; children: ReactNode; lead?: ReactNode }) {
  return (
    <div>
      <div className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div><h1 className="font-[family-name:var(--font-display)] text-2xl font-bold text-heading">{title}</h1>{lead && <p className="mt-1 text-sm text-muted">{lead}</p>}</div>
        {actions && <div className="flex flex-wrap gap-2">{actions}</div>}
      </div>
      {children}
    </div>
  );
}

export const Card = ({ title, children, className = "", actions }: { title?: ReactNode; children: ReactNode; className?: string; actions?: ReactNode }) => (
  <section className={`rounded-lg border border-line bg-white p-5 ${className}`}>
    {(title || actions) && <div className="mb-4 flex flex-wrap items-center justify-between gap-3">{title && <h2 className="text-base font-semibold text-heading">{title}</h2>}{actions}</div>}
    {children}
  </section>
);

export function Btn({ children, onClick, kind = "secondary", disabled, type = "button", small }: { children: ReactNode; onClick?: () => void; kind?: "primary" | "secondary" | "danger" | "ghost"; disabled?: boolean; type?: "button" | "submit"; small?: boolean }) {
  const k = { primary: "bg-brand text-white hover:bg-brand-600 border-brand", secondary: "bg-white text-heading border-line hover:border-heading/40", danger: "bg-white text-[#9f1d1d] border-[#f3c8c8] hover:bg-[#fdf0f0]", ghost: "border-transparent text-cobalt hover:text-brand" }[kind];
  return <button type={type} onClick={onClick} disabled={disabled} className={`inline-flex items-center justify-center gap-1.5 rounded-md border font-semibold transition-colors disabled:opacity-50 ${small ? "min-h-8 px-2.5 text-xs" : "min-h-10 px-4 text-sm"} ${k}`}>{children}</button>;
}

export const Badge = ({ children, tone = "neutral" }: { children: ReactNode; tone?: "neutral" | "ok" | "warn" | "risk" | "brand" }) => {
  const c = { neutral: "bg-mist text-heading", ok: "bg-[#e6f6ef] text-[#0b5e47]", warn: "bg-[#fff4e5] text-[#7a4300]", risk: "bg-[#fdecec] text-[#9f1d1d]", brand: "bg-brand-50 text-[#4b23b5]" }[tone];
  return <span className={`inline-flex items-center rounded-full px-2 py-0.5 text-xs font-semibold ${c}`}>{children}</span>;
};

export function Field({ label, children, hint }: { label: string; children: ReactNode; hint?: string }) {
  return <label className="block text-sm"><span className="mb-1 block font-semibold text-heading">{label}</span>{children}{hint && <span className="mt-1 block text-xs text-muted">{hint}</span>}</label>;
}
export const inputCls = "w-full rounded-md border border-line bg-white px-3 py-2 text-sm text-heading focus:border-brand focus:outline-none focus:ring-2 focus:ring-brand/20";

export const Loading = () => <p className="flex items-center gap-2 py-10 text-sm text-muted" role="status"><Loader2 size={16} className="animate-spin" aria-hidden="true" /> Loading…</p>;
export const ErrorBox = ({ children }: { children: ReactNode }) => <p className="form-error my-3" role="alert">{children}</p>;
export const Empty = ({ children }: { children: ReactNode }) => <p className="py-8 text-center text-sm text-muted">{children}</p>;

export function Table({ head, children }: { head: ReactNode[]; children: ReactNode }) {
  return (
    <div className="overflow-x-auto rounded-lg border border-line bg-white">
      <table className="w-full min-w-[640px] text-left text-sm">
        <thead className="bg-paper text-xs uppercase tracking-wide text-muted"><tr>{head.map((h, i) => <th key={i} scope="col" className="px-4 py-3 font-semibold">{h}</th>)}</tr></thead>
        <tbody className="divide-y divide-line">{children}</tbody>
      </table>
    </div>
  );
}
export const Td = ({ children, className = "" }: { children?: ReactNode; className?: string }) => <td className={`px-4 py-3 align-top text-body ${className}`}>{children}</td>;

/** Bilingual text input pair (EN required, NL optional). */
export function LInput({ label, value, onChange, area }: { label: string; value: any; onChange: (v: { en: string; nl?: string }) => void; area?: boolean }) {
  const v = value ?? { en: "", nl: "" };
  const C = area ? "textarea" : "input";
  return (
    <fieldset className="text-sm">
      <legend className="mb-1 font-semibold text-heading">{label}</legend>
      <div className="grid gap-2 sm:grid-cols-2">
        <label className="block"><span className="sr-only">{label} (English)</span><span className="text-xs text-muted">EN</span><C className={inputCls} rows={area ? 3 : undefined} value={v.en ?? ""} onChange={(e: any) => onChange({ ...v, en: e.target.value })} /></label>
        <label className="block"><span className="sr-only">{label} (Dutch)</span><span className="text-xs text-muted">NL</span><C className={inputCls} rows={area ? 3 : undefined} value={v.nl ?? ""} onChange={(e: any) => onChange({ ...v, nl: e.target.value })} /></label>
      </div>
    </fieldset>
  );
}

/** JSON editor for advanced structures (options, conditions, triggers). */
export function JsonField({ label, value, onChange, hint, rows = 6 }: { label: string; value: unknown; onChange: (v: unknown, valid: boolean) => void; hint?: string; rows?: number }) {
  const [text, setText] = useState(() => (value === undefined || value === null ? "" : JSON.stringify(value, null, 2)));
  const [err, setErr] = useState<string | null>(null);
  return (
    <Field label={label} hint={err ?? hint}>
      <textarea className={`${inputCls} font-mono text-xs ${err ? "border-risk" : ""}`} rows={rows} value={text} spellCheck={false}
        onChange={(e) => {
          setText(e.target.value);
          if (!e.target.value.trim()) { setErr(null); onChange(undefined, true); return; }
          try { onChange(JSON.parse(e.target.value), true); setErr(null); } catch { setErr("Invalid JSON"); onChange(undefined, false); }
        }} />
    </Field>
  );
}

export function Toast({ msg, onClose }: { msg: { text: string; tone: "ok" | "risk" } | null; onClose: () => void }) {
  useEffect(() => { if (!msg) return; const t = setTimeout(onClose, 5000); return () => clearTimeout(t); }, [msg, onClose]);
  if (!msg) return null;
  return <div role="status" className={`fixed bottom-5 right-5 z-50 max-w-md rounded-md px-4 py-3 text-sm font-medium shadow-lg ${msg.tone === "ok" ? "bg-[#0b5e47] text-white" : "bg-[#9f1d1d] text-white"}`}>{msg.text}</div>;
}

export function Pager({ page, size, total, onPage }: { page: number; size: number; total: number; onPage: (p: number) => void }) {
  const pages = Math.max(1, Math.ceil(total / size));
  if (pages <= 1) return null;
  return <div className="mt-4 flex items-center justify-end gap-2 text-sm text-muted"><Btn small disabled={page <= 1} onClick={() => onPage(page - 1)}>Previous</Btn> Page {page} of {pages} <Btn small disabled={page >= pages} onClick={() => onPage(page + 1)}>Next</Btn></div>;
}
