 
"use client";

import { useCallback, useEffect, useState } from "react";
import { AdminCtx } from "./ctx";
import { BarChart3, ClipboardList, Globe, Image as ImageIcon, Newspaper, FileText, FolderTree, Gauge, LayoutDashboard, ListChecks, LogOut, Menu, Settings, Sparkles, Users, X } from "lucide-react";
import { api, setCsrf, type User, can } from "./lib";
import { Toast } from "./ui";
import { Overview, Assessments, AssessmentDetail, Leads, LeadDetail, Reports, Analytics } from "./data";
import { Templates, TemplateDetail, Questions, Categories, Scoring, Rules } from "./content";
import { SettingsView } from "./system";
import { WebsitePages, Articles, MediaLibrary } from "./website";
import Login from "./Login";


const NAV: { hash: string; label: string; icon: typeof Gauge; cap: string; group: string }[] = [
  { hash: "overview", label: "Overview", icon: LayoutDashboard, cap: "view", group: "" },
  { hash: "leads", label: "Leads", icon: Users, cap: "leads", group: "Leads & results" },
  { hash: "assessments", label: "Completed assessments", icon: ClipboardList, cap: "assessments", group: "Leads & results" },
  { hash: "reports", label: "Reports", icon: FileText, cap: "reports", group: "Leads & results" },
  { hash: "analytics", label: "Analytics", icon: BarChart3, cap: "view", group: "Leads & results" },
  { hash: "website", label: "Pages", icon: Globe, cap: "view", group: "Website" },
  { hash: "articles", label: "Articles", icon: Newspaper, cap: "view", group: "Website" },
  { hash: "media", label: "Images", icon: ImageIcon, cap: "view", group: "Website" },
  { hash: "templates", label: "Assessment templates", icon: ListChecks, cap: "view", group: "Assessments" },
  { hash: "questions", label: "Question bank", icon: FolderTree, cap: "view", group: "Assessments" },
  { hash: "categories", label: "Categories", icon: FolderTree, cap: "view", group: "Assessments" },
  { hash: "scoring", label: "Scoring", icon: Gauge, cap: "view", group: "Assessments" },
  { hash: "rules", label: "Recommendation rules", icon: Sparkles, cap: "view", group: "Assessments" },
  { hash: "settings", label: "Settings", icon: Settings, cap: "settings", group: "System" },
];

function useHash() {
  const [hash, setHash] = useState("");
  useEffect(() => {
    const on = () => setHash(window.location.hash.replace(/^#\/?/, "") || "overview");
    on();
    window.addEventListener("hashchange", on);
    return () => window.removeEventListener("hashchange", on);
  }, []);
  return hash;
}

export default function AdminApp() {
  const [user, setUser] = useState<User | null>(null);
  const [checked, setChecked] = useState(false);
  const [toast, setToast] = useState<{ text: string; tone: "ok" | "risk" } | null>(null);
  const [menu, setMenu] = useState(false);
  const hash = useHash();

  useEffect(() => {
    api<{ user: User; csrf: string }>("GET", "/me").then((r) => { setCsrf(r.csrf); setUser(r.user); }).catch(() => {}).finally(() => setChecked(true));
    const out = () => setUser(null);
    window.addEventListener("bk-admin-logout", out);
    return () => window.removeEventListener("bk-admin-logout", out);
  }, []);
  // eslint-disable-next-line react-hooks/set-state-in-effect -- close the mobile menu on navigation
  useEffect(() => { setMenu(false); }, [hash]);

  const notify = useCallback((text: string, tone: "ok" | "risk" = "ok") => setToast({ text, tone }), []);
  const go = useCallback((h: string) => { window.location.hash = `/${h}`; }, []);
  const clearToast = useCallback(() => setToast(null), []);

  if (!checked) return <div className="grid min-h-screen place-items-center bg-paper text-sm text-muted">Loading…</div>;
  if (!user) return <Login onLogin={(u, c) => { setCsrf(c); setUser(u); }} />;

  const [section, rawId] = hash.split("/");
  const id = rawId ? decodeURIComponent(rawId) : rawId;
  const nav = NAV.filter((n) => can(user, n.cap));
  let view: React.ReactNode;
  switch (section) {
    case "leads": view = id ? <LeadDetail id={Number(id)} /> : <Leads />; break;
    case "assessments": view = id ? <AssessmentDetail id={Number(id)} /> : <Assessments />; break;
    case "reports": view = <Reports />; break;
    case "analytics": view = <Analytics />; break;
    case "templates": view = id ? <TemplateDetail id={Number(id)} /> : <Templates />; break;
    case "questions": view = <Questions />; break;
    case "categories": view = <Categories />; break;
    case "scoring": view = <Scoring />; break;
    case "rules": view = <Rules />; break;
    case "settings": view = <SettingsView />; break;
    case "website": view = <WebsitePages docKey={id} />; break;
    case "articles": view = <Articles slug={id} />; break;
    case "media": view = <MediaLibrary />; break;
    default: view = <Overview />;
  }

  return (
    <AdminCtx.Provider value={{ user, notify, go }}>
      <div className="min-h-screen bg-paper lg:grid lg:grid-cols-[15rem_minmax(0,1fr)]">
        <a href="#admin-main" className="sr-only-focusable sr-only">Skip to content</a>
        <aside className={`${menu ? "block" : "hidden"} fixed inset-0 z-40 overflow-y-auto bg-ink-950 p-4 text-ink-200 lg:sticky lg:top-0 lg:block lg:h-screen`}>
          <div className="mb-6 flex items-center justify-between">
            <span className="font-[family-name:var(--font-display)] text-lg font-bold text-white">Blaze<span className="text-brand-300">Konzult</span> <span className="text-xs font-normal text-ink-300">Admin</span></span>
            <button className="lg:hidden" onClick={() => setMenu(false)} aria-label="Close menu"><X size={20} /></button>
          </div>
          <nav aria-label="Admin">
            <ul className="space-y-0.5">
              {nav.map((n, i) => {
                const on = section === n.hash || (!section && n.hash === "overview");
                const head = n.group && n.group !== nav[i - 1]?.group;
                return (
                  <li key={n.hash}>
                    {head && <p className="mb-1 mt-5 px-3 text-[0.6875rem] font-semibold uppercase tracking-wider text-ink-300">{n.group}</p>}
                    <a href={`#/${n.hash}`} aria-current={on ? "page" : undefined} className={`flex items-center gap-2.5 rounded-md px-3 py-2 text-sm ${on ? "bg-ink-800 font-semibold text-white" : "hover:bg-ink-900 hover:text-white"}`}><n.icon size={16} aria-hidden="true" />{n.label}</a>
                  </li>
                );
              })}
            </ul>
          </nav>
          <div className="mt-8 border-t border-ink-700 pt-4 text-xs text-ink-300">
            <p className="font-semibold text-ink-200">{user.name}</p><p>{user.email} · {user.role}</p>
            <button className="mt-3 inline-flex items-center gap-1.5 text-ink-200 hover:text-white" onClick={async () => { await api("POST", "/logout", {}).catch(() => {}); setUser(null); }}><LogOut size={14} /> Sign out</button>
          </div>
        </aside>
        <div>
          <header className="flex items-center justify-between border-b border-line bg-white px-4 py-3 lg:hidden">
            <span className="font-bold text-heading">BlazeKonzult Admin</span>
            <button onClick={() => setMenu(true)} aria-label="Open menu" className="p-2"><Menu size={20} /></button>
          </header>
          <main id="admin-main" className="mx-auto max-w-7xl p-4 sm:p-8">{view}</main>
        </div>
      </div>
      <Toast msg={toast} onClose={clearToast} />
    </AdminCtx.Provider>
  );
}
