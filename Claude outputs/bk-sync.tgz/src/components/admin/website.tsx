/* eslint-disable @typescript-eslint/no-explicit-any, @next/next/no-img-element -- generic editor walks arbitrary content JSON; admin thumbnails need no optimiser */
"use client";

import { useCallback, useEffect, useId, useMemo, useRef, useState } from "react";
import { ArrowDown, ArrowUp, ChevronDown, Copy, ExternalLink, History, ImagePlus, Plus, RotateCcw, Trash2, Upload, X } from "lucide-react";
import { API_BASE } from "@/lib/assessment/api";
import { REGISTRY, defaultsFor, defaultArticleSlugs, newArticle, articleDefaults, type ArticleDoc } from "@/content/defaults";
import { mergeDefaults } from "@/content/merge";
import { localizeHref } from "@/lib/locale";
import { api, can, fmtDate, AdminError, getCsrf } from "./lib";
import { useAdmin } from "./ctx";
import { Badge, Btn, Card, Empty, ErrorBox, Field, inputCls, Loading, Page, Table, Td, useLoad } from "./ui";

const enc = encodeURIComponent;
const err = (e: unknown) => (e as Error).message;

/* ------------------------------ Labels & field kinds ------------------------------ */
const WORDS: Record<string, string> = { seo: "SEO", href: "Link", cta: "Button", faq: "FAQ", faqs: "FAQs", nl: "Dutch", en: "English", url: "URL", linkedin: "LinkedIn URL", p: "Paragraph", h: "Heading", ul: "Bullet list" };
function label(key: string): string {
  if (/^\d+$/.test(key)) return `Item ${Number(key) + 1}`;
  if (WORDS[key]) return WORDS[key];
  const words = key.replace(/([a-z])([A-Z0-9])/g, "$1 $2").replace(/[_-]/g, " ").toLowerCase().split(" ").map((w) => (w === "cta" ? "button" : w === "seo" ? "SEO" : w === "href" ? "link" : w === "url" ? "URL" : w === "faq" ? "FAQ" : w));
  const s = words.join(" ");
  return s.charAt(0).toUpperCase() + s.slice(1);
}
const IMAGE_KEY = /^(image|src|coverImage|founderPhoto|socialImage|.*Image|.*Photo)$/;
const LONG_KEY = /^(lead|description|body|text|answer|excerpt|summary|blurb|note|privacyNote|quote|paragraphs|regulatory|outcome|bestSuitedFor|bestFor|shortDescription|p|intro|notice)$/;
const CHOICES: Record<string, string[]> = {
  status: ["published", "draft"],
  visual: ["maturity", "regulation", "governance", "cycle", "awareness", "response", "assurance"],
  category: ["Assess", "Prepare", "Govern", "Educate", "Respond", "Improve"],
};
const ICONS = "Activity AlertTriangle BarChart3 Briefcase Bug CalendarCheck2 CalendarRange ClipboardCheck Cloud CloudCog Compass Crosshair DatabaseBackup Factory FileCheck2 FileQuestion FileText FolderCheck Gauge GraduationCap HeartPulse Landmark LifeBuoy Link2 ListChecks ListOrdered ListTodo MailWarning MessagesSquare Network Presentation Route Scale ScanSearch SearchCheck SearchX Server Shield ShieldCheck Table2 Truck UserCheck UserX Users2 Lock KeyRound Building2 Globe Laptop Cpu".split(" ");

/** Blank copy of a value, used as the template when adding an item to a list. */
function blank(v: any): any {
  if (typeof v === "string") return "";
  if (typeof v === "number") return 0;
  if (typeof v === "boolean") return false;
  if (Array.isArray(v)) return v.length && typeof v[0] === "string" ? [""] : [];
  if (v && typeof v === "object") return Object.fromEntries(Object.entries(v).map(([k, x]) => [k, blank(x)]));
  return "";
}
function summary(v: any): string {
  if (typeof v === "string") return v;
  if (v && typeof v === "object") { for (const k of ["title", "name", "label", "question", "heading", "code", "phase", "step", "h", "p"]) if (typeof v[k] === "string" && v[k]) return v[k]; }
  return "";
}

/* ------------------------------------ Field editor ------------------------------------ */
type EditorProps = { name: string; value: any; template?: any; onChange: (v: any) => void; depth: number; pickImage: (cb: (url: string) => void) => void };

function ValueEditor({ name, value, template, onChange, depth, pickImage }: EditorProps) {
  if (name === "body" && Array.isArray(value)) return <BlocksEditor value={value} onChange={onChange} />;
  if (typeof value === "string") return <StringField name={name} value={value} onChange={onChange} pickImage={pickImage} />;
  if (typeof value === "number") return <Field label={label(name)}><input type="number" className={inputCls} value={value} onChange={(e) => onChange(Number(e.target.value))} /></Field>;
  if (typeof value === "boolean") return <label className="flex items-center gap-2 text-sm"><input type="checkbox" className="check" checked={value} onChange={(e) => onChange(e.target.checked)} /> {label(name)}</label>;
  if (Array.isArray(value)) return <ListEditor name={name} value={value} template={template} onChange={onChange} depth={depth} pickImage={pickImage} />;
  if (value && typeof value === "object") return <ObjectEditor name={name} value={value} template={template} onChange={onChange} depth={depth} pickImage={pickImage} />;
  return null;
}

function StringField({ name, value, onChange, pickImage }: { name: string; value: string; onChange: (v: string) => void; pickImage: EditorProps["pickImage"] }) {
  const id = useId();
  if (IMAGE_KEY.test(name)) {
    return (
      <div className="text-sm">
        <label htmlFor={id} className="mb-1 block font-semibold text-heading">{label(name)}</label>
        <div className="flex flex-wrap items-center gap-3">
          {value && /^(\/|https:)/.test(value) && <img src={value} alt="" className="h-16 w-16 rounded-md border border-line object-cover" />}
          <input id={id} className={`${inputCls} min-w-0 flex-1`} value={value} placeholder="No image (uses the default design)" onChange={(e) => onChange(e.target.value)} />
          <Btn small onClick={() => pickImage(onChange)}><ImagePlus size={14} /> Choose</Btn>
          {value && <Btn small kind="ghost" onClick={() => onChange("")}>Remove</Btn>}
        </div>
      </div>
    );
  }
  if (CHOICES[name] && (CHOICES[name].includes(value) || !value)) {
    return <Field label={label(name)}><select className={inputCls} value={value} onChange={(e) => onChange(e.target.value)}>{CHOICES[name].map((c) => <option key={c}>{c}</option>)}</select></Field>;
  }
  if (name === "icon") {
    return <Field label="Icon" hint="Name of a Lucide icon"><input className={inputCls} list="bk-icons" value={value} onChange={(e) => onChange(e.target.value)} /></Field>;
  }
  if (name === "date") return <Field label="Date"><input type="date" className={inputCls} value={value} onChange={(e) => onChange(e.target.value)} /></Field>;
  const long = LONG_KEY.test(name) || value.length > 90 || value.includes("\n");
  return (
    <Field label={label(name)} hint={long ? "Links: [text](/page) · bold: **text**" : /href|Href/.test(name) ? "A page path like /contact or a full https:// address" : undefined}>
      {long ? <textarea className={inputCls} rows={Math.min(8, Math.max(2, Math.ceil(value.length / 90)))} value={value} onChange={(e) => onChange(e.target.value)} />
        : <input className={inputCls} value={value} onChange={(e) => onChange(e.target.value)} />}
    </Field>
  );
}

function ObjectEditor({ name, value, template, onChange, depth, pickImage }: EditorProps) {
  const entries = Object.entries(value);
  const simple = entries.every(([, v]) => typeof v !== "object" || v === null);
  const body = (
    <div className={`grid gap-4 ${simple && entries.length > 1 && entries.every(([k, v]) => typeof v !== "string" || (!LONG_KEY.test(k) && (v as string).length < 90)) ? "sm:grid-cols-2" : ""}`}>
      {entries.map(([k, v]) => <ValueEditor key={k} name={k} value={v} template={template?.[k]} depth={depth + 1} pickImage={pickImage} onChange={(nv) => onChange({ ...value, [k]: nv })} />)}
    </div>
  );
  if (depth === 0) return body;
  if (depth === 1) return <Section title={label(name)}>{body}</Section>;
  return <fieldset className="rounded-md border border-line p-4"><legend className="px-1 text-sm font-semibold text-heading">{label(name)}</legend>{body}</fieldset>;
}

function Section({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <section className="rounded-lg border border-line bg-white">
      <button type="button" className="flex w-full items-center justify-between px-5 py-4 text-left font-semibold text-heading" aria-expanded={open} onClick={() => setOpen(!open)}>
        {title}<ChevronDown size={18} className={`transition-transform ${open ? "rotate-180" : ""}`} aria-hidden="true" />
      </button>
      {open && <div className="border-t border-line p-5">{children}</div>}
    </section>
  );
}

function ListEditor({ name, value, template, onChange, depth, pickImage }: EditorProps) {
  const tpl = value[0] ?? (Array.isArray(template) ? template[0] : undefined) ?? "";
  const move = (i: number, d: number) => { const a = [...value]; const [x] = a.splice(i, 1); a.splice(i + d, 0, x); onChange(a); };
  const strings = value.every((v: any) => typeof v === "string") && typeof tpl === "string";
  const inner = (
    <div className="space-y-2">
      {value.map((item: any, i: number) => (
        <div key={i} className={strings ? "flex items-start gap-2" : "rounded-md border border-line bg-paper p-3"}>
          {strings ? (
            <div className="flex-1">{(LONG_KEY.test(name) || item.length > 90)
              ? <textarea aria-label={`${label(name)} ${i + 1}`} className={inputCls} rows={Math.min(6, Math.max(2, Math.ceil(item.length / 90)))} value={item} onChange={(e) => { const a = [...value]; a[i] = e.target.value; onChange(a); }} />
              : <input aria-label={`${label(name)} ${i + 1}`} className={inputCls} value={item} onChange={(e) => { const a = [...value]; a[i] = e.target.value; onChange(a); }} />}</div>
          ) : (
            <div className="mb-2 flex items-center justify-between gap-2"><span className="truncate text-xs font-semibold text-muted">{i + 1}. {summary(item).slice(0, 80)}</span></div>
          )}
          {!strings && <ValueEditor name={String(i)} value={item} template={tpl} depth={depth + 1} pickImage={pickImage} onChange={(nv) => { const a = [...value]; a[i] = nv; onChange(a); }} />}
          <div className={`flex gap-0.5 ${strings ? "shrink-0 pt-1.5" : "mt-2 justify-end"}`}>
            <button type="button" aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)} className="p-1 disabled:opacity-30"><ArrowUp size={15} /></button>
            <button type="button" aria-label="Move down" disabled={i === value.length - 1} onClick={() => move(i, 1)} className="p-1 disabled:opacity-30"><ArrowDown size={15} /></button>
            <button type="button" aria-label="Remove" onClick={() => onChange(value.filter((_: any, j: number) => j !== i))} className="p-1 text-[#9f1d1d]"><Trash2 size={15} /></button>
          </div>
        </div>
      ))}
      <Btn small onClick={() => onChange([...value, blank(tpl)])}><Plus size={13} /> Add {strings ? "line" : "item"}</Btn>
    </div>
  );
  if (depth <= 1) return <Section title={`${label(name)} (${value.length})`}>{inner}</Section>;
  return <div className="text-sm"><p className="mb-1 font-semibold text-heading">{label(name)}</p>{inner}</div>;
}

/** Article body: headings, paragraphs and bullet lists. */
function BlocksEditor({ value, onChange }: { value: any[]; onChange: (v: any[]) => void }) {
  const set = (i: number, b: any) => { const a = [...value]; a[i] = b; onChange(a); };
  const move = (i: number, d: number) => { const a = [...value]; const [x] = a.splice(i, 1); a.splice(i + d, 0, x); onChange(a); };
  return (
    <section className="rounded-lg border border-line bg-white p-5">
      <h3 className="font-semibold text-heading">Article text</h3>
      <p className="mt-1 text-xs text-muted">Paragraphs and list items support [link text](/page) and **bold**.</p>
      <div className="mt-4 space-y-3">
        {value.map((b, i) => (
          <div key={i} className="rounded-md border border-line bg-paper p-3">
            <div className="mb-2 flex items-center justify-between text-xs font-semibold text-muted">
              <span>{"h" in b ? "Heading" : "ul" in b ? "Bullet list (one item per line)" : "Paragraph"}</span>
              <span className="flex gap-0.5">
                <button type="button" aria-label="Move up" disabled={i === 0} onClick={() => move(i, -1)} className="p-1 disabled:opacity-30"><ArrowUp size={14} /></button>
                <button type="button" aria-label="Move down" disabled={i === value.length - 1} onClick={() => move(i, 1)} className="p-1 disabled:opacity-30"><ArrowDown size={14} /></button>
                <button type="button" aria-label="Remove block" onClick={() => onChange(value.filter((_, j) => j !== i))} className="p-1 text-[#9f1d1d]"><Trash2 size={14} /></button>
              </span>
            </div>
            {"h" in b ? <input aria-label="Heading" className={`${inputCls} font-semibold`} value={b.h} onChange={(e) => set(i, { h: e.target.value })} />
              : "ul" in b ? <textarea aria-label="Bullet list" className={inputCls} rows={Math.max(3, b.ul.length + 1)} value={b.ul.join("\n")} onChange={(e) => set(i, { ul: e.target.value.split("\n") })} />
                : <textarea aria-label="Paragraph" className={inputCls} rows={Math.min(10, Math.max(3, Math.ceil((b.p ?? "").length / 90)))} value={b.p} onChange={(e) => set(i, { p: e.target.value })} />}
          </div>
        ))}
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Btn small onClick={() => onChange([...value, { h: "" }])}><Plus size={13} /> Heading</Btn>
        <Btn small onClick={() => onChange([...value, { p: "" }])}><Plus size={13} /> Paragraph</Btn>
        <Btn small onClick={() => onChange([...value, { ul: [""] }])}><Plus size={13} /> Bullet list</Btn>
      </div>
    </section>
  );
}

/* ------------------------------------ Media picker ------------------------------------ */
function useMediaPicker() {
  const [cb, setCb] = useState<((url: string) => void) | null>(null);
  const pick = useCallback((f: (url: string) => void) => setCb(() => f), []);
  const modal = cb ? <MediaModal onPick={(u) => { cb(u); setCb(null); }} onClose={() => setCb(null)} /> : null;
  return { pick, modal };
}

async function uploadFiles(files: FileList | File[], csrfFetch: (f: File) => Promise<any>) {
  const out = [];
  for (const f of Array.from(files)) out.push(await csrfFetch(f));
  return out;
}
function uploader() {
  return async (f: File) => {
    const res = await fetch(`${API_BASE}/admin/media`, { method: "POST", credentials: "same-origin", headers: { "content-type": f.type || "application/octet-stream", "x-filename": enc(f.name), "x-csrf-token": getCsrf() }, body: f });
    const j = await res.json().catch(() => null);
    if (!res.ok) throw new AdminError(j?.error?.message ?? "Upload failed", res.status, "upload");
    return j;
  };
}

function MediaModal({ onPick, onClose }: { onPick: (url: string) => void; onClose: () => void }) {
  const { data, loading, error, reload } = useLoad(() => api("GET", "/media"));
  const [busy, setBusy] = useState<string | null>(null);
  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-ink-950/60 p-4" role="dialog" aria-modal="true" aria-label="Choose an image">
      <div className="mx-auto max-w-4xl rounded-lg bg-white p-6">
        <div className="flex items-center justify-between gap-3">
          <h2 className="text-lg font-bold text-heading">Choose an image</h2>
          <div className="flex items-center gap-2">
            <label className="inline-flex min-h-10 cursor-pointer items-center gap-1.5 rounded-md border border-brand bg-brand px-4 text-sm font-semibold text-white">
              <Upload size={15} /> Upload
              <input type="file" accept="image/png,image/jpeg,image/webp,image/gif" className="sr-only" onChange={async (e) => {
                if (!e.target.files?.length) return; setBusy("Uploading…");
                try { const [m] = await uploadFiles(e.target.files, uploader()); onPick(m.url); } catch (x) { setBusy(err(x)); return; }
                setBusy(null); reload();
              }} />
            </label>
            <Btn onClick={onClose}><X size={15} /> Close</Btn>
          </div>
        </div>
        {busy && <p className="mt-3 text-sm text-muted" role="status">{busy}</p>}
        {loading ? <Loading /> : error ? <ErrorBox>{error}</ErrorBox> : !data.media.length ? <Empty>No images yet. Upload one.</Empty> : (
          <ul className="mt-5 grid grid-cols-2 gap-3 sm:grid-cols-4">
            {data.media.map((m: any) => (
              <li key={m.id}><button type="button" onClick={() => onPick(m.url)} className="group block w-full rounded-md border border-line p-2 text-left hover:border-brand">
                <img src={m.url} alt={m.alt ?? ""} className="aspect-square w-full rounded object-cover" />
                <span className="mt-1 block truncate text-xs text-muted">{m.original_name}</span>
              </button></li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

/* ------------------------------------ Document editor ------------------------------------ */
function DocEditor({ docKey, title, path, onDone, isNewArticle }: { docKey: string; title: string; path: string; onDone?: () => void; isNewArticle?: boolean }) {
  const { user, notify } = useAdmin();
  const isNl = docKey.startsWith("nl:");
  const baseKey = isNl ? docKey.slice(3) : docKey;
  const isArticle = baseKey.startsWith("article:");
  // A Dutch article translation starts from the (possibly edited) English article.
  const english = useLoad(() => (isNl && isArticle ? api("GET", `/content/${enc(baseKey)}`) : Promise.resolve(null)), [docKey]);
  const defaults = useMemo(() => {
    if (isArticle) { const base = articleDefaults(baseKey.slice(8)) ?? newArticle(); return isNl ? mergeDefaults(base as any, english.data?.doc?.data) : base; }
    return defaultsFor(baseKey, isNl ? "nl" : "en");
  }, [baseKey, isArticle, isNl, english.data]);
  const saved = useLoad(() => api("GET", `/content/${enc(docKey)}`), [docKey]);
  const [value, setValue] = useState<any>(null);
  const [dirty, setDirty] = useState(false);
  const [showRev, setShowRev] = useState(false);
  const { pick, modal } = useMediaPicker();
  const edit = can(user, "content");

  useEffect(() => {
    if (saved.loading || saved.error || english.loading) return;
    // eslint-disable-next-line react-hooks/set-state-in-effect -- initialise the form from loaded content
    setValue(mergeDefaults(defaults as any, saved.data?.doc?.data));
    setDirty(false);
  }, [saved.loading, saved.error, saved.data, defaults, english.loading]);

  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => { if (dirty) { e.preventDefault(); } };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);

  if (saved.loading || !value) return saved.error ? <ErrorBox>{saved.error}</ErrorBox> : <Loading />;
  const customised = !!saved.data?.doc;
  const save = async () => {
    try { await api("PUT", `/content/${enc(docKey)}`, { data: value }); notify("Saved. The change is live on the website."); setDirty(false); saved.reload(); onDone?.(); }
    catch (e) { notify(err(e), "risk"); }
  };
  return (
    <Page title={title} lead={<>{customised ? <>Edited {fmtDate(saved.data.doc.updated_at)}</> : isNewArticle ? "New article (not saved yet)" : "Showing the original website text (not edited yet)"} · <a className="inline-flex items-center gap-1 text-cobalt underline underline-offset-2" href={path} target="_blank" rel="noopener">View page <ExternalLink size={12} /></a></>}
      actions={<>
        <Btn onClick={() => setShowRev(!showRev)}><History size={15} /> Revisions</Btn>
        {edit && customised && !isNewArticle && <Btn onClick={async () => { if (!confirm("Discard all edits to this page and go back to the original website text? (A revision is kept.)")) return; await api("DELETE", `/content/${enc(docKey)}`); notify("Restored the original text."); saved.reload(); }}><RotateCcw size={15} /> Reset to original</Btn>}
        {edit && <Btn kind="primary" onClick={save} disabled={!dirty && customised}>{dirty ? "Save and publish" : "Saved"}</Btn>}
      </>}>
      <datalist id="bk-icons">{ICONS.map((i) => <option key={i} value={i} />)}</datalist>
      {showRev && <Revisions docKey={docKey} onRestored={() => { setShowRev(false); saved.reload(); }} />}
      {dirty && <p className="sticky top-2 z-10 mb-4 rounded-md border border-warn/40 bg-[#fff8ec] px-4 py-2 text-sm text-heading" role="status">You have unsaved changes. <button className="font-semibold text-cobalt underline" onClick={save}>Save and publish</button></p>}
      <fieldset disabled={!edit} className="space-y-3">
        <ValueEditor name="" value={value} template={defaults} depth={0} pickImage={pick} onChange={(v) => { setValue(v); setDirty(true); }} />
      </fieldset>
      {edit && <div className="mt-6"><Btn kind="primary" onClick={save} disabled={!dirty && customised}>{dirty ? "Save and publish" : "Saved"}</Btn></div>}
      {modal}
    </Page>
  );
}

function Revisions({ docKey, onRestored }: { docKey: string; onRestored: () => void }) {
  const { user, notify } = useAdmin();
  const { data, loading, error } = useLoad(() => api("GET", `/content/${enc(docKey)}/revisions`), [docKey]);
  return (
    <Card title="Revisions" className="mb-6">
      {loading ? <Loading /> : error ? <ErrorBox>{error}</ErrorBox> : !data.revisions.length ? <Empty>No saved versions yet.</Empty> : (
        <ul className="divide-y divide-line text-sm">
          {data.revisions.map((r: any, i: number) => (
            <li key={r.id} className="flex flex-wrap items-center justify-between gap-2 py-2">
              <span>{fmtDate(r.created_at)} · {r.user_name ?? "system"} · {r.action === "reset" ? "reset to original" : r.action}{i === 0 && <> <Badge tone="ok">current</Badge></>}</span>
              {can(user, "content") && i > 0 && <Btn small onClick={async () => { if (!confirm("Restore this version? It becomes live immediately.")) return; await api("POST", `/revisions/${r.id}/restore`, {}); notify("Version restored."); onRestored(); }}>Restore</Btn>}
            </li>
          ))}
        </ul>
      )}
    </Card>
  );
}

/* ------------------------------------ Pages list ------------------------------------ */
const LANG_KEY = "bk-admin-lang";
function useLang(): ["en" | "nl", (l: "en" | "nl") => void] {
  const [lang, setLang] = useState<"en" | "nl">("en");
  // eslint-disable-next-line react-hooks/set-state-in-effect -- restore the last chosen language after hydration
  useEffect(() => { try { if (localStorage.getItem(LANG_KEY) === "nl") setLang("nl"); } catch { /* ignore */ } }, []);
  return [lang, (l) => { setLang(l); try { localStorage.setItem(LANG_KEY, l); } catch { /* ignore */ } }];
}
function LangTabs({ lang, setLang }: { lang: "en" | "nl"; setLang: (l: "en" | "nl") => void }) {
  return (
    <div role="tablist" aria-label="Language" className="inline-flex rounded-md border border-line bg-white p-0.5">
      {(["en", "nl"] as const).map((l) => (
        <button key={l} role="tab" aria-selected={lang === l} onClick={() => setLang(l)} className={`rounded px-3 py-1.5 text-sm font-semibold ${lang === l ? "bg-ink-950 text-white" : "text-body hover:text-heading"}`}>{l === "en" ? "English" : "Nederlands"}</button>
      ))}
    </div>
  );
}

export function WebsitePages({ docKey }: { docKey?: string }) {
  const { data, error, loading } = useLoad(() => api("GET", "/content"), [docKey]);
  const [lang, setLang] = useLang();
  if (docKey) {
    const nl = docKey.startsWith("nl:");
    const info = REGISTRY.find((r) => r.key === (nl ? docKey.slice(3) : docKey));
    if (!info) return <ErrorBox>Unknown page.</ErrorBox>;
    const other = nl ? docKey.slice(3) : `nl:${docKey}`;
    return <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <a href="#/website" className="text-sm text-cobalt">← All pages</a>
        <LangTabs lang={nl ? "nl" : "en"} setLang={(l) => { setLang(l); window.location.hash = `/website/${enc(l === "nl" ? `nl:${info.key}` : info.key)}`; }} />
      </div>
      <DocEditor key={docKey} docKey={docKey} title={`${info.label}${nl ? " (Nederlands)" : " (English)"}`} path={localizeHref(info.path, nl ? "nl" : "en")} />
      <p className="mt-6 text-xs text-muted">The English and Dutch versions are edited separately. <a className="text-cobalt underline" href={`#/website/${enc(other)}`}>Open the {nl ? "English" : "Dutch"} version</a>.</p>
    </>;
  }
  const saved = new Map<string, any>((data?.docs ?? []).map((d: any) => [d.doc_key, d]));
  const groups = ["Site", "Pages", "Services", "Legal"] as const;
  const k = (key: string) => (lang === "nl" ? `nl:${key}` : key);
  return (
    <Page title="Website" lead="Edit the text, links, images and SEO of every page, in English and Dutch. Saved changes are live immediately and every save is kept as a revision."
      actions={<LangTabs lang={lang} setLang={setLang} />}>
      {loading ? <Loading /> : error ? <ErrorBox>{error}</ErrorBox> : groups.map((g) => (
        <div key={g} className="mb-8">
          <h2 className="mb-3 text-sm font-semibold uppercase tracking-wide text-muted">{g}</h2>
          <Table head={["Page", "Address", "Status", ""]}>
            {REGISTRY.filter((r) => r.group === g).map((r) => {
              const s = saved.get(k(r.key));
              const path = localizeHref(r.path, lang);
              return (
                <tr key={r.key}>
                  <Td><a className="font-semibold text-cobalt" href={`#/website/${enc(k(r.key))}`}>{r.label}</a></Td>
                  <Td><a className="text-xs text-muted hover:text-cobalt" href={path} target="_blank" rel="noopener">{path}</a></Td>
                  <Td>{s ? <><Badge tone="brand">Edited</Badge> <span className="text-xs text-muted">{fmtDate(s.updated_at)}{s.updated_by_name ? ` · ${s.updated_by_name}` : ""}</span></> : <Badge>Original</Badge>}</Td>
                  <Td><Btn small onClick={() => { window.location.hash = `/website/${enc(k(r.key))}`; }}>Edit</Btn></Td>
                </tr>
              );
            })}
          </Table>
        </div>
      ))}
      <p className="text-xs text-muted">The assessment pages are managed under Assessment templates. Insights articles are under Articles.</p>
    </Page>
  );
}

/* ------------------------------------ Articles ------------------------------------ */
export function Articles({ slug }: { slug?: string }) {
  const { user, notify, go } = useAdmin();
  const { data, error, loading, reload } = useLoad(() => api("GET", "/content"), [slug]);
  const [articles, setArticles] = useState<any[] | null>(null);
  const [newSlug, setNewSlug] = useState("");
  const isNew = slug?.startsWith("new:");

  useEffect(() => {
    if (!data) return;
    let live = true;
    (async () => {
      const keys = data.docs.filter((d: any) => d.doc_key.startsWith("article:")).map((d: any) => d.doc_key.slice(8));
      const all = new Set<string>([...defaultArticleSlugs, ...keys]);
      const rows = await Promise.all([...all].map(async (s) => {
        const savedRow = keys.includes(s) ? (await api("GET", `/content/${enc(`article:${s}`)}`)).doc : null;
        const merged: ArticleDoc & { deleted?: boolean } = mergeDefaults((articleDefaults(s) ?? newArticle()) as any, savedRow?.data);
        return { slug: s, ...merged, edited: !!savedRow, builtIn: defaultArticleSlugs.includes(s), updated_at: savedRow?.updated_at, dutch: data.docs.some((d: any) => d.doc_key === `nl:article:${s}`) };
      }));
      if (live) setArticles(rows.filter((r) => !r.deleted).sort((a, b) => (a.date < b.date ? 1 : -1)));
    })().catch(() => setArticles([]));
    return () => { live = false; };
  }, [data]);

  if (slug) {
    const nl = slug.startsWith("nl:");
    const real = isNew ? slug.slice(4) : nl ? slug.slice(3) : slug;
    return <>
      <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
        <a href="#/articles" className="text-sm text-cobalt">← All articles</a>
        {!isNew && <LangTabs lang={nl ? "nl" : "en"} setLang={(l) => go(`articles/${l === "nl" ? `nl:${real}` : real}`)} />}
      </div>
      <DocEditor key={slug} docKey={nl ? `nl:article:${real}` : `article:${real}`} title={isNew ? "New article" : nl ? "Dutch version of the article" : "Edit article (English)"} path={`${nl ? "/nl" : ""}/resources/${real}/`} isNewArticle={isNew} onDone={() => { if (isNew) go(`articles/${real}`); }} />
      {nl && <p className="mt-6 text-xs text-muted">Until you save a Dutch version, Dutch visitors see the English article with a short note.</p>}
    </>;
  }
  const slugOk = /^[a-z0-9]+(-[a-z0-9]+)*$/.test(newSlug);
  return (
    <Page title="Articles" lead="Insights articles. Drafts are hidden from the website until their status is set to published.">
      {can(user, "content") && (
        <Card title="New article" className="mb-6">
          <form className="flex flex-wrap items-end gap-3" onSubmit={(e) => { e.preventDefault(); if (!slugOk) return; if (articles?.some((a) => a.slug === newSlug)) { notify("An article with this address already exists.", "risk"); return; } go(`articles/new:${newSlug}`); }}>
            <Field label="Web address (slug)" hint={`The article will be at /resources/${newSlug || "your-slug"}/`}><input className={`${inputCls} w-80 max-w-full`} value={newSlug} onChange={(e) => setNewSlug(e.target.value.toLowerCase().replace(/[^a-z0-9-]/g, "-").replace(/-+/g, "-"))} placeholder="e.g. backup-basics-for-smes" /></Field>
            <Btn type="submit" kind="primary" disabled={!slugOk}><Plus size={15} /> Create</Btn>
          </form>
        </Card>
      )}
      {loading || !articles ? (error ? <ErrorBox>{error}</ErrorBox> : <Loading />) : !articles.length ? <Empty>No articles.</Empty> : (
        <Table head={["Article", "Category", "Date", "Status", "Dutch", ""]}>
          {articles.map((a) => (
            <tr key={a.slug}>
              <Td><a className="font-semibold text-cobalt" href={`#/articles/${a.slug}`}>{a.title || a.slug}</a><span className="block text-xs text-muted">/resources/{a.slug}/</span></Td>
              <Td>{a.category}</Td><Td>{a.date}</Td>
              <Td><Badge tone={a.status === "draft" ? "warn" : "ok"}>{a.status}</Badge> {a.edited && <Badge tone="brand">edited</Badge>}</Td>
              <Td><a className="text-xs font-semibold text-cobalt" href={`#/articles/nl:${a.slug}`}>{a.dutch ? "Edit translation" : "Translate"}</a></Td>
              <Td className="space-x-1">
                <a className="inline-flex items-center gap-1 text-xs text-cobalt" href={`/resources/${a.slug}/`} target="_blank" rel="noopener">View <ExternalLink size={11} /></a>
                {can(user, "delete") && <Btn small kind="danger" onClick={async () => {
                  if (!confirm(`Delete "${a.title}" from the website?`)) return;
                  try {
                    if (a.builtIn) await api("PUT", `/content/${enc(`article:${a.slug}`)}`, { data: { deleted: true, status: "draft" } });
                    else await api("DELETE", `/content/${enc(`article:${a.slug}`)}`);
                    notify("Article deleted."); reload();
                  } catch (e) { notify(err(e), "risk"); }
                }}><Trash2 size={13} /></Btn>}
              </Td>
            </tr>
          ))}
        </Table>
      )}
    </Page>
  );
}

/* ------------------------------------ Media library ------------------------------------ */
export function MediaLibrary() {
  const { user, notify } = useAdmin();
  const { data, error, loading, reload } = useLoad(() => api("GET", "/media"));
  const [busy, setBusy] = useState(false);
  const input = useRef<HTMLInputElement>(null);
  return (
    <Page title="Images" lead="PNG, JPEG, WebP or GIF, up to 5 MB each. Use the Choose button on any image field to place an image on a page."
      actions={can(user, "content") && <>
        <input ref={input} type="file" multiple accept="image/png,image/jpeg,image/webp,image/gif" className="sr-only" aria-label="Upload images" onChange={async (e) => {
          if (!e.target.files?.length) return; setBusy(true);
          try { const r = await uploadFiles(e.target.files, uploader()); notify(`${r.length} image(s) uploaded.`); } catch (x) { notify(err(x), "risk"); }
          setBusy(false); e.target.value = ""; reload();
        }} />
        <Btn kind="primary" disabled={busy} onClick={() => input.current?.click()}><Upload size={15} /> {busy ? "Uploading…" : "Upload images"}</Btn>
      </>}>
      {loading ? <Loading /> : error ? <ErrorBox>{error}</ErrorBox> : !data.media.length ? <Empty>No images uploaded yet.</Empty> : (
        <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {data.media.map((m: any) => (
            <li key={m.id} className="rounded-lg border border-line bg-white p-3">
              <img src={m.url} alt={m.alt ?? ""} className="aspect-[4/3] w-full rounded object-cover" />
              <p className="mt-2 truncate text-sm font-semibold text-heading" title={m.original_name}>{m.original_name}</p>
              <p className="text-xs text-muted">{m.width && `${m.width}×${m.height} · `}{Math.round(m.size / 1024)} KB · {fmtDate(m.created_at)}</p>
              {m.used_in.length > 0 && <p className="mt-1 text-xs text-muted">Used in: {m.used_in.join(", ")}</p>}
              <label className="mt-2 block text-xs"><span className="text-muted">Alt text (describes the image)</span>
                <input className={`${inputCls} py-1 text-xs`} defaultValue={m.alt ?? ""} disabled={!can(user, "content")} onBlur={async (e) => { if (e.target.value !== (m.alt ?? "")) { await api("PATCH", `/media/${m.id}`, { alt: e.target.value }); notify("Alt text saved."); } }} />
              </label>
              <div className="mt-2 flex gap-1">
                <Btn small onClick={() => { navigator.clipboard?.writeText(m.url); notify("Image address copied."); }}><Copy size={12} /> Copy address</Btn>
                {can(user, "delete") && <Btn small kind="danger" onClick={async () => { if (!confirm("Delete this image?")) return; try { await api("DELETE", `/media/${m.id}`); reload(); } catch (x) { notify(err(x), "risk"); } }}><Trash2 size={12} /></Btn>}
              </div>
            </li>
          ))}
        </ul>
      )}
    </Page>
  );
}
